clear all
clc
DIR = pwd;                                                  % Current directory
%Patient = char(DIR(end-9:end));                             % Get patient ID
filedir = char(string(DIR) + string('\*'));                 % Current directory as a character array
files_data = dir(fullfile(filedir, 'Patient0*.mat'));               % struct with all .csv files in the current directory


for j = 1:size(files_data,1)
    load_temp = string(files_data(j).folder) + "\" + string(files_data(j).name);
    load(load_temp);
    
        for ext_idx = 1:6
        names = {'max_Acc_X' ; 'max_Acc_X' ; 'max_Acc_X' ; 'max_Acc_X' ; 'max_AL_Acc_X' ; 'max_AL_Acc_X'};

        D = dataframes{ext_idx,1};                               % Picks the dataframe belonging to the extremity index the code is looping over
        nan = isnan(D{:,end});                                   % Finds the NaN values in the clinical scores
        D = D(~nan,:);                                           % Remove the rows with NaN values as a clinical score
        size_D{j,ext_idx} = size(D,1)
        end
        
        if j == 1
        dataframeTrain_dystonia_lower_generalise           = dataframeTrain_dystonia_lower;
        dataframeTrain_dystonia_upper_generalise           = dataframeTrain_dystonia_upper;
        dataframeTrain_dystonia_total_generalise           = dataframeTrain_dystonia_total;
        dataframeTrain_choreoathetosis_lower_generalise    = dataframeTrain_choreoathetosis_lower;
        dataframeTrain_choreoathetosis_upper_generalise    = dataframeTrain_choreoathetosis_upper;
        dataframeTrain_choreoathetosis_total_generalise    = dataframeTrain_choreoathetosis_total;
        TABLE_ML_TOTAL_generalise                          = TABLE_ML_TOTAL;
        TABLE_ML_TOTAL_lower_generalise                    = TABLE_ML_TOTAL_lower;
        TABLE_ML_TOTAL_upper_generalise                    = TABLE_ML_TOTAL_upper;
        Clinical_Scores_TOTAL_median_generalise            = Clinical_Scores_TOTAL_median;

        else 
        dataframeTrain_dystonia_lower_generalise         = [dataframeTrain_dystonia_lower_generalise ; dataframeTrain_dystonia_lower];
        dataframeTrain_dystonia_upper_generalise         = [dataframeTrain_dystonia_upper_generalise ; dataframeTrain_dystonia_upper];
        dataframeTrain_dystonia_total_generalise         = [dataframeTrain_dystonia_total_generalise ; dataframeTrain_dystonia_total];
        dataframeTrain_choreoathetosis_lower_generalise  = [dataframeTrain_choreoathetosis_lower_generalise ; dataframeTrain_choreoathetosis_lower];
        dataframeTrain_choreoathetosis_upper_generalise  = [dataframeTrain_choreoathetosis_upper_generalise ; dataframeTrain_choreoathetosis_upper];
        dataframeTrain_choreoathetosis_total_generalise  = [dataframeTrain_choreoathetosis_total_generalise ; dataframeTrain_choreoathetosis_total];
        TABLE_ML_TOTAL_generalise                        = [TABLE_ML_TOTAL_generalise ; TABLE_ML_TOTAL];
        TABLE_ML_TOTAL_lower_generalise                  = [TABLE_ML_TOTAL_lower_generalise ; TABLE_ML_TOTAL_lower];
        TABLE_ML_TOTAL_upper_generalise                  = [TABLE_ML_TOTAL_upper_generalise ; TABLE_ML_TOTAL_upper];
        Clinical_Scores_TOTAL_median_generalise          = [Clinical_Scores_TOTAL_median_generalise ; Clinical_Scores_TOTAL_median];
        end

end

dataframeTrain_dystonia_lower = dataframeTrain_dystonia_lower_generalise;
dataframeTrain_dystonia_upper = dataframeTrain_dystonia_upper_generalise;
dataframeTrain_dystonia_total = dataframeTrain_dystonia_total_generalise;
dataframeTrain_choreoathetosis_lower = dataframeTrain_choreoathetosis_lower_generalise;
dataframeTrain_choreoathetosis_upper = dataframeTrain_choreoathetosis_upper_generalise;
dataframeTrain_choreoathetosis_total = dataframeTrain_choreoathetosis_total_generalise;
dataframes = {dataframeTrain_dystonia_lower ; dataframeTrain_dystonia_upper ; dataframeTrain_choreoathetosis_lower ; dataframeTrain_choreoathetosis_upper ; dataframeTrain_dystonia_total ; dataframeTrain_choreoathetosis_total};
TABLE_ML_TOTAL = TABLE_ML_TOTAL_generalise;
TABLE_ML_TOTAL_lower = TABLE_ML_TOTAL_lower_generalise;
TABLE_ML_TOTAL_upper = TABLE_ML_TOTAL_upper_generalise;
Clinical_Scores_TOTAL_median = Clinical_Scores_TOTAL_median_generalise;




clear testInd trainInd
for k = 1:6
    for ext_idx = 1:6
        if k == 1
            testInd{k,ext_idx} = 1 : (size_D{1,ext_idx} + size_D{2,ext_idx});
        elseif k == 2
            L = length(testInd{1,ext_idx});
            testInd{2,ext_idx} = L + 1 : L + (size_D{3,ext_idx} + size_D{4,ext_idx});
        elseif k == 3
            L = length(testInd{1,ext_idx}) + length(testInd{2,ext_idx});
            testInd{3,ext_idx} = L + 1 : L + (size_D{5,ext_idx} + size_D{6,ext_idx});
        elseif k == 4
            L = length(testInd{1,ext_idx}) + length(testInd{2,ext_idx}) + length(testInd{3,ext_idx});
            testInd{4,ext_idx} = L + 1 : L + (size_D{7,ext_idx} + size_D{8,ext_idx});
        elseif k == 5
            L = length(testInd{1,ext_idx}) + length(testInd{2,ext_idx}) + length(testInd{3,ext_idx}) + length(testInd{4,ext_idx});
            testInd{5,ext_idx} = L + 1 : L + (size_D{9,ext_idx} + size_D{10,ext_idx});
        elseif k == 6
            L = length(testInd{1,ext_idx}) + length(testInd{2,ext_idx}) + length(testInd{3,ext_idx}) + length(testInd{4,ext_idx}) + length(testInd{5,ext_idx});
            testInd{6,ext_idx} = L + 1 : L + (size_D{11,ext_idx} + size_D{12,ext_idx});
        end
        
    end
end
testInd


for k = 1:6
    for ext_idx = 1:6
        trainInd{k,ext_idx} = 1: testInd{6, ext_idx}(1,end);
        trainInd{k,ext_idx} = setdiff(trainInd{k,ext_idx}, testInd{k,ext_idx});
    end
end
trainInd


for i = 1:6
    for j = 1:6
        trainInd_DL{i,j}  =  trainInd{i,j}(1:round(5/6*length(trainInd{i,j})));
        valInd_DL{i,j}    =  trainInd{i,j}(round(5/6*length(trainInd{i,j}))+1:end);
        testInd_DL{i,j}   =  testInd{i,j}(randperm(numel(testInd{i,j})));
        
        size_y_test_DL(i,j)  =  length(testInd_DL{i,j});
        size_y_val_DL(i,j)   =  length(valInd_DL{i,j});
    end
end

% Save
save_name = "partition_generalise2";
save(save_name, 'dataframes','trainInd', 'testInd', 'trainInd_DL', 'testInd_DL', 'valInd_DL', 'size_y_test_DL', 'size_y_val_DL','size_D' , 'TABLE_ML_TOTAL', 'TABLE_ML_TOTAL_lower' , 'TABLE_ML_TOTAL_upper', 'Clinical_Scores_TOTAL_median', 'dataframeTrain_dystonia_lower', 'dataframeTrain_dystonia_upper', 'dataframeTrain_choreoathetosis_lower', 'dataframeTrain_choreoathetosis_upper', 'dataframeTrain_choreoathetosis_total','dataframeTrain_dystonia_total')
