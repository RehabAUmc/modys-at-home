clear all
clc
close all
tic 

Extremity_idx = 1:6 ;
% 1 = Lower (dystonia)
% 2 = Upper (dystonia)
% 3 = Lower (choreoathetosis)
% 4 = Upper (choreoathetosis)
% 5 = Total (dystonia)
% 6 = Total (choreoathetosis

DIR = pwd;

% loads previously saved results to speed up running the code
load_ALL_data           = "load_ALL_models_"         + string(DIR(end-9:end)) + ".mat";
load_DL_data            = "load_DL_models_"          + string(DIR(end-9:end)) + ".mat";
load_ML_data            = "load_ML_models_"          + string(DIR(end-9:end)) + ".mat";
load_preprocess_data    = "load_preprocess_data_"    + string(DIR(end-9:end)) + ".mat";
load_sensordata         = "load_sensordata_"         + string(DIR(end-9:end)) + ".mat";
load_Timetables_all_day = "load_Timetables_all_day_" + string(DIR(end-9:end)) + ".mat";

% % if file exists, load that file and skip part of the code
% if size(dir(fullfile(DIR, load_ALL_data)),1) == 1
%     disp('loading part 1-4: all previously saved data')
%     load(load_ALL_data)
% elseif size(dir(fullfile(DIR, load_DL_data)),1) == 1
%     disp('loading part 1-3: previously saved preprocessed data, ML models & results, and DL models & results')
%     load(load_DL_data)
% elseif size(dir(fullfile(DIR, load_ML_data)),1) == 1
%     disp('loading part 1-2: previously saved preprocessed data, and ML models & results')
%     load(load_ML_data)
% elseif size(dir(fullfile(DIR, load_preprocess_data)),1) == 1
%     disp('loading part 1: previously saved pre-processed data')
%     load(load_preprocess_data) 
% end

start_time = datetime('now');


%%%%% PRE-PROCESSING DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%if size(dir(fullfile(DIR, load_preprocess_data)),1) == 0    % Only run this part if it has not been run yet 
disp('running PART 1: preprocessing data')

% Specify frequency sensor and window length 
fs_xsens      = 60;                                         % Frequency Xsens sensors [Hz]
window_length = 5 * fs_xsens;                               % Window length [datapoints in 5 second window]

% Get struct with all .csv (sensor data) and .txt (clinical scores) files in current directory
DIR = pwd;                                                  % Current directory
Patient = char(DIR(end-9:end));                             % Get patient ID
Patient_nr = str2double(Patient(:,end-1:end));              % Get patient number
filedir = char(string(DIR) + string('\*'));                 % Current directory as a character array
files_data = dir(fullfile(filedir, '*.csv'));               % struct with all .csv files in the current directory
files_data_scores = dir(fullfile(filedir, '*.txt'));        % struct with all .txt files in the current directory

% Get the subfolder names
files = dir(DIR);                                           % Get a struct of all files and subfolders in the current folder.
dirFlags = [files.isdir];                                   % Get a logical vector that tells which is a directory.
subFolders = files(dirFlags);                               % Extract only those that are directories.
subFolders(1:2)=[];
for k = 1 : length(subFolders)
  subFolders_names{k,1}= subFolders(k).name;                % Folder names {cell array}
end

for i = 1:length(subFolders)
    filedir2 = char(string(DIR) + "\" + string(subFolders_names{i, 1}));
    files_data_scores_per_folder{i,1} = dir(fullfile(filedir2, '*.txt'));        % struct with all .txt files (scores) in the current directory
    scored_total_per_map(i) = size(files_data_scores_per_folder{i,1},1);
end

% Tabular datastores with .csv and .txt files
ds = tabularTextDatastore(DIR,'IncludeSubfolders', true,'FileExtensions',{'.csv'});                 % datastore with with csv files (sensor data)
if isempty(files_data_scores) == 0                                                                  % if there are no clinical scores, this step skips creating a datastore with scores
    ds_scores = tabularTextDatastore(DIR,'IncludeSubfolders', true,'FileExtensions',{'.txt'});      % datastore with with txt files (clinical scores)
    idx_ds_HHA = find(contains(ds_scores.Files,'HHA'));
    idx_ds_CPI = find(contains(ds_scores.Files,'CPI'));
    idx_ds_NHE = find(contains(ds_scores.Files,'NHE'));
    idx_ds_scorers = {idx_ds_HHA idx_ds_CPI idx_ds_NHE};
    ds_scores_HHA = ds_scores.Files(idx_ds_HHA);
    ds_scores_CPI = ds_scores.Files(idx_ds_CPI);
    ds_scores_NHE = ds_scores.Files(idx_ds_NHE);
    ds_scores_scorers = {ds_scores_HHA ds_scores_CPI ds_scores_NHE};
else disp("ERROR: no clinical scores")
end

% Indexing of files in datastore ds
fileContainsEnkel_L = find(cellfun(@(c)contains(c,'Enkel_l'),ds.Files)==1);                         % Indices of csv files in ds containing 'Enkel_l'
fileContainsEnkel_R = find(cellfun(@(c)contains(c,'Enkel_r'),ds.Files)==1);                         % Indices of csv files in ds containing 'Enkel_r'
  if  isempty(fileContainsEnkel_L) == 1
      fileContainsEnkel_L = find(cellfun(@(c)contains(c,'Enkle_l'),ds.Files)==1);                   % Indices of csv files in ds containing 'Enkle_l'
      fileContainsEnkel_R = find(cellfun(@(c)contains(c,'Enkle_r'),ds.Files)==1);                   % Indices of csv files in ds containing 'Enkle_l'
  end
fileContainsPols_L  = find(cellfun(@(c)contains(c,'Pols_l'),ds.Files)==1);                          % Indices of csv files in ds containing 'Pols_l'
fileContainsPols_R  = find(cellfun(@(c)contains(c,'Pols_r'),ds.Files)==1);                          % Indices of csv files in ds containing 'Pols_r'
file_indices = [fileContainsEnkel_L fileContainsEnkel_R fileContainsPols_L fileContainsPols_R];     % Each row contains indices of the files of a single measurement. This matrix is handy for the loop.

% Load .csv files into tables
if size(dir(fullfile(DIR, load_sensordata)),1) == 1
    disp('Loading previously saved MATLAB (.mat) files of the sensordata')
    load(load_sensordata)
else
ds.ReadSize = 'file';                                                                               % Changes maximum readsize to infinite
disp("Loading Excel files of " + string(Patient) + " into Matlab")
for i=1:size(ds.Files,1)                                                                            % 1 : amount of csv files
    Data{i} = readtable(ds.Files{i, 1});                                                            % Creates tables with the data from each csv file
    NAN =  sum(isnan(table2array(Data{i}(end,:))));                                                 % Sometimes the final row of the csv file is incomplete. This line calculates how many NaN's there are in the final row.
    if NAN > 1                                              
        Data{i}(end,:) = [];                                                                        % If the is any NaN in the final row, this row is deleted.
    end 
    h(i) = height(Data{i});                                                                         % Heights of each 'Data' table
    if h(i) > 1296000                                       
        Data{i}(1296001:end,:) = [];                                                                % If the height of the table > 1296000 (6 hours of data), the rest of the data is removed. This is done since the sensor is sometimes left on and huge amounts of irrelevant sensor data then need to be processed. The threshold of 6 hours can be changed.  
        [idx_sensor,idx_map]=find(file_indices'==i);                                                % idx_sensor and idx_map are needed to display which csv file was shorted (two lines below)
        idx_sensor_names = ["left ankle" ; "right ankle" ; "left wrist" ; "right wrist"];
        disp("Sensor " + idx_sensor_names(idx_sensor) + " in measurement " + string(subFolders_names(idx_map)) + " was on for longer than 6 hours. Data shortened to 6 hours.")
    end
end
disp('Saving sensordata as .mat file')
save(load_sensordata,'Data')
end

% File Datastore with video files in current directory
ds_videos   = fileDatastore(DIR,'ReadFcn',@myread,'FileExtensions','.mp4','IncludeSubfolders', true);  

% Calculate number of total/active/inactive videos per subfolder
videos_not_scored_number=0;
scorers = ["HHA";"CPI";"NHE"];
%scorers = ["HHA";"CPI"];
b0_extend = ['/*_HHA.txt';'/*_CPI.txt';'/*_NHE.txt']; 

for p = 1:size(scorers,1)
    for i = 1:size(file_indices,1)                                              % 1 : number of measurements
        Sub_name = subFolders(i).name;                                          % subfolder name of measurement looping
        Sub_name_full = char(string(DIR) + "\" + string(Sub_name));             % Folder directory of subfolder looping
        a0=dir([Sub_name_full '/*.mp4']);                                       % Total videos in subfolder looping
        a1=dir([Sub_name_full '/Active*.mp4']);                                 % Active videos in subfolder looping
        a2=dir([Sub_name_full '/Inactive*.mp4']);                               % Inactive videos in subfolder looping
        vids_total_per_map(i)=size(a0,1);                                       % Total videos per subfolder            
        vids_Active_per_map(i)=size(a1,1);                                      % Active videos per subfolder
        vids_Inactive_per_map(i)=size(a2,1);                                    % Inactive videos per subfolder

        clear a01 b01 b02 b0 idx_videos_not_scored idx_videos_scored
        for k = 1:size(a0,1)                                                    % 1 : number of videos in subfolder looping
            a01(k,1) = string(a0(k).name(1:end-4));                             % Names of videos in subfolder looping
            a02{k,i} = string(a0(k).name);                                      % Names of videos in subfolder looping saved in a cell
        end

        if isempty(files_data_scores)==0
            scored_total_per_map
        if scored_total_per_map(i) < 3*vids_total_per_map(i)
            b0=dir([Sub_name_full b0_extend(p,:)]);
            scored_videos_per_folder(i,p)=size(b0,1);                                % Number of clinically scored videos per subfolder
           
            % Check if all videos are scored
            if scored_videos_per_folder(i,p) > 0
                for k = 1:size(b0,1)
                    b01(k,1) = string(b0(k).name(1:end-8));
                    b02{k,i} = string(b0(k).name);
                end
                ab = [a01;b01];
                for k = 1:size(a0,1)
                    if find(a01(k) == b01)
                    idx_videos_scored(k)= 1;
                    else
                        idx_videos_scored(k) = 0;
                    end
                end
                idx_videos_not_scored = find(idx_videos_scored==0);
                idx_videos_not_scored_folder{:,i} = idx_videos_not_scored;
                if isempty(idx_videos_not_scored)==0
                    for k=idx_videos_not_scored
                        videos_not_scored{k,i} = string(a0(k).name);
                        disp("Not scored: folder = " + string(subFolders_names{i,1}) + "  video = " + videos_not_scored{k,i} + "  by " + scorers(p))
                        videos_not_scored_number = videos_not_scored_number+1;
                    end
                else   videos_not_scored{1,i} = []; %string('-');
                       disp(scorers(p) + " scored all videos are scored in folder " + string(subFolders_names{i,1}))
                end
            else disp(scorers(p) + " scored no videos are scored in folder " + string(subFolders_names{i,1}))
            end  
        elseif scored_total_per_map(i) == 3*vids_total_per_map(i)
            disp("All videos scored in folder " + string(subFolders_names{i,1}))
            b0=dir([Sub_name_full b0_extend(p,:)]);
            scored_videos_per_folder(i,p)=size(b0,1);
        else
            disp("No videos scored in folder " + string(subFolders_names{i,1}))
        end
        end


    end
end
    
vids = [vids_total_per_map; vids_Active_per_map; vids_Inactive_per_map];    % [Total videos; Active videos; Inactive videos] per subfolder
vids2 = [vids_Active_per_map; vids_Inactive_per_map];                       % [Active videos; Inactive videos] per subfolder

toc



% Loop per measurement / subfolder

for Q = 1:size(file_indices,1)                                          % Q = 1 : number of measurements/subfolders
    
    disp("Analyzing subfolder: " + string(Q))
   
    clearvars -except Extremity_idx scorers ds ds_scores_scorers idx_ds_scorers idx_ds_HHA idx_ds_CPI idx_ds_NHE Info1 Duration start_time end_time Video idx_map lost_video_idx idx_map Verloren_videos TABLE_ML_per_measurement Q vids vids2 ds_videos N DIR DIR_string filedir files_data files dirFlags subFolders B fs_xsens window_length file_indices h Data ds fileContainsEnkel_L fileContainsEnkel_R fileContainsPols_L fileContainsPols_R vids_total_per_map vids_Active_per_map vids_Inactive_per_map files_data_scores ds_scores scored_videos_per_folder clinical_scores_windows_vert duration_hours lost_videos_amount lost_videos_idx subFolders_names ERROR ERROR2 check_length_total N_CS_total N_videos_total file_indices data window_length load_ALL_data load_ML_data load_DL_data load_preprocess_data load_sensordata TT scored_videos_per_folder
    
    measurement_indices = file_indices(Q,:);                            % Indices of the files of the looping measurement

    % Accelerometer and gyroscope data per sensor
    S1 = table2array(Data{1,measurement_indices(1)}(:,[2:11 1]));       % Left ankle sensor data of looping measurement
    S2 = table2array(Data{1,measurement_indices(2)}(:,[2:11 1]));       % Right ankle sensor data of looping measurement
    S3 = table2array(Data{1,measurement_indices(3)}(:,[2:11 1]));       % Left wrist sensor data of looping measurement
    S4 = table2array(Data{1,measurement_indices(4)}(:,[2:11 1]));       % Right wrist sensor data of looping measurement

    Sc = {S1; S2; S3; S4};                                              % Vertically concatenate matrices into cell array

    S1t = S1(:,1);                                                      % SampleTimeFine of left ankle sensor data of looping measurement
    S2t = S2(:,1);                                                      % SampleTimeFine of right ankle sensor data of looping measurement
    S3t = S3(:,1);                                                      % SampleTimeFine of left wrist sensor data of looping measurement
    S4t = S4(:,1);                                                      % SampleTimeFine of right wrist sensor data of looping measurement
    
    [S_Time, Error_SampleTimeFine, cut_off] = sync_SampleTimeFine(S1t, S2t, S3t, S4t, Sc, Q);   % The fuction sync_SampleTimeFine returns the unique SampleTimeFine values of all sensors combined. This array is needed to synchronized the data from the four sensors.
    ERROR2{Q,1} = Error_SampleTimeFine;                                 % Error: SampleTimeFine's are not synchronized the whole measurement

    if cut_off{Q,1} > 0                                                 % index after which the synchronization has been lost
        Data{1,measurement_indices(1,1)}(cut_off{Q,1}:end,:) = [];      % remove (left ankle)  data after the synchronization loss
        Data{1,measurement_indices(1,2)}(cut_off{Q,1}:end,:) = [];      % remove (right ankle) data after the synchronization loss
        Data{1,measurement_indices(1,3)}(cut_off{Q,1}:end,:) = [];      % remove (left wrist)  data after the synchronization loss
        Data{1,measurement_indices(1,4)}(cut_off{Q,1}:end,:) = [];      % remove (right wrist) data after the synchronization loss
        Sc{1}(cut_off{Q,1}:end,:) = [];                                 % remove (left ankle)  data after the synchronization loss
        Sc{2}(cut_off{Q,1}:end,:) = [];                                 % remove (right ankle) data after the synchronization loss
        Sc{3}(cut_off{Q,1}:end,:) = [];                                 % remove (left wrist)  data after the synchronization loss
        Sc{4}(cut_off{Q,1}:end,:) = [];                                 % remove (right wrist) data after the synchronization loss
    end
    
    % Calculate start time, end time and duration
    for i = measurement_indices
        length_data(i-measurement_indices(1)+1) = size(Data{1,i},1);
    end
    [~,idx_shortest_data] = min(length_data);
    file_name = ds.Files(measurement_indices(1,1));
    D0 = datetime(char(file_name{1}(end-22:end-15)),'InputFormat','yyyyMMdd',"Format","dd-MMM-yyyy HH:mm:ss.SSS");
    spf = @(x) sprintf('%010d',x);
    start = Data{1,measurement_indices(1,idx_shortest_data)}(1,1);
    start_t = timeofday(datetime(rowfun(spf,start(:,'PacketCounter'),"OutputFormat","cell"),'InputFormat',"HHmmssSSS"));
    start_t = start_t + D0;
    start_time(Q,1) = start_t;
    End = Data{1,measurement_indices(1,idx_shortest_data)}(end,1);
    end_t = timeofday(datetime(rowfun(spf,End(:,'PacketCounter'),"OutputFormat","cell"),'InputFormat',"HHmmssSSS"));
    end_t = end_t + D0;
    df = [0; diff(Data{1,measurement_indices(1,idx_shortest_data)}.PacketCounter)<0];
    end_t = end_t + days(sum(df));
    end_time(Q,1) = end_t;
    Duration(Q,1) = end_t - start_t;
    disp("Duration of measurement " + string(subFolders_names(Q)) + " is: " + string(Duration(Q,1)))
    
    windows        = floor(size(S_Time,1) / window_length); % number of windows 

    % Interpolate data to fill up missing samples. Needed to create a
    % synchronized dataframe.
    for i = 1:10
        Sensor_Ankle_L(:,i)  = interp1(Sc{1}(:,1),Sc{1}(:,i+1),S_Time,'linear','extrap'); 
        Sensor_Ankle_R(:,i)  = interp1(Sc{2}(:,1),Sc{2}(:,i+1),S_Time,'linear','extrap'); 
        Sensor_Wrist_L(:,i)  = interp1(Sc{3}(:,1),Sc{3}(:,i+1),S_Time,'linear','extrap'); 
        Sensor_Wrist_R(:,i)  = interp1(Sc{4}(:,1),Sc{4}(:,i+1),S_Time,'linear','extrap'); 
    end

    % Calculate total acceleration and total angular velocity for each sensor
    Acc_T_Ankle_L = sqrt(sum(Sensor_Ankle_L(:,1:3).^2,2));
    Acc_T_Ankle_R = sqrt(sum(Sensor_Ankle_R(:,1:3).^2,2));
    Acc_T_Wrist_L = sqrt(sum(Sensor_Wrist_L(:,1:3).^2,2));
    Acc_T_Wrist_R = sqrt(sum(Sensor_Wrist_R(:,1:3).^2,2));
    Gyr_T_Ankle_L = sqrt(sum(Sensor_Ankle_L(:,4:6).^2,2));
    Gyr_T_Ankle_R = sqrt(sum(Sensor_Ankle_R(:,4:6).^2,2));
    Gyr_T_Wrist_L = sqrt(sum(Sensor_Wrist_L(:,4:6).^2,2));
    Gyr_T_Wrist_R = sqrt(sum(Sensor_Wrist_R(:,4:6).^2,2));
    
    % Add the total acceleration and total angular velocity to the dataframe
    Data_Sensor_Ankle_L = [Sensor_Ankle_L(:,4:6) Acc_T_Ankle_L Sensor_Ankle_L(:,7:9) Gyr_T_Ankle_L Sensor_Ankle_L(:,1:3)];
    Data_Sensor_Ankle_R = [Sensor_Ankle_R(:,4:6) Acc_T_Ankle_R Sensor_Ankle_R(:,7:9) Gyr_T_Ankle_R Sensor_Ankle_R(:,1:3)];
    Data_Sensor_Wrist_L = [Sensor_Wrist_L(:,4:6) Acc_T_Wrist_L Sensor_Wrist_L(:,7:9) Gyr_T_Wrist_L Sensor_Wrist_L(:,1:3)];
    Data_Sensor_Wrist_R = [Sensor_Wrist_R(:,4:6) Acc_T_Wrist_R Sensor_Wrist_R(:,7:9) Gyr_T_Wrist_R Sensor_Wrist_R(:,1:3)];

    % Create a table with the synchronized data from all four sensors
    Table = [table(S_Time) array2table([Data_Sensor_Ankle_L Data_Sensor_Ankle_R Data_Sensor_Wrist_L Data_Sensor_Wrist_R])];                     % Create Result Table
    Table.Properties.VariableNames = {'SampleTimeFine','AL_Acc_X','AL_Acc_Y','AL_Acc_Z','AL_Acc_T','AL_Gyr_X','AL_Gyr_Y','AL_Gyr_Z','AL_Gyr_T','AL_Euler_X','AL_Euler_Y','AL_Euler_Z','AR_Acc_X','AR_Acc_Y','AR_Acc_Z','AR_Acc_T','AR_Gyr_X','AR_Gyr_Y','AR_Gyr_Z','AR_Gyr_T','AR_Euler_X','AR_Euler_Y','AR_Euler_Z','WL_Acc_X','WL_Acc_Y','WL_Acc_Z','WL_Acc_T','WL_Gyr_X','WL_Gyr_Y','WL_Gyr_Z','WL_Gyr_T','WL_Euler_X','WL_Euler_Y','WL_Euler_Z','WR_Acc_X','WR_Acc_Y','WR_Acc_Z','WR_Acc_T','WR_Gyr_X','WR_Gyr_Y','WR_Gyr_Z','WR_Gyr_T','WR_Euler_X','WR_Euler_Y','WR_Euler_Z'};
    
    % Timetable all day
    load_Timetables_all_day = "load_Timetables_all_day_" + string(DIR(end-9:end)) + ".mat";
    if size(dir(fullfile(DIR, load_Timetables_all_day)),1) == 0
        for i=1:44
            Table_windows{i}=reshape(table2array(Table(1:windows*window_length,i+1)),window_length,windows).';
        end
    Table_windows_total = horzcat(table(Table_windows{:}));
    Table_windows_total.Properties.VariableNames = {'AL_Acc_X','AL_Acc_Y','AL_Acc_Z','AL_Acc_T','AL_Gyr_X','AL_Gyr_Y','AL_Gyr_Z','AL_Gyr_T','AL_Euler_X','AL_Euler_Y','AL_Euler_Z','AR_Acc_X','AR_Acc_Y','AR_Acc_Z','AR_Acc_T','AR_Gyr_X','AR_Gyr_Y','AR_Gyr_Z','AR_Gyr_T','AR_Euler_X','AR_Euler_Y','AR_Euler_Z','WL_Acc_X','WL_Acc_Y','WL_Acc_Z','WL_Acc_T','WL_Gyr_X','WL_Gyr_Y','WL_Gyr_Z','WL_Gyr_T','WL_Euler_X','WL_Euler_Y','WL_Euler_Z','WR_Acc_X','WR_Acc_Y','WR_Acc_Z','WR_Acc_T','WR_Gyr_X','WR_Gyr_Y','WR_Gyr_Z','WR_Gyr_T','WR_Euler_X','WR_Euler_Y','WR_Euler_Z'};
    time_axis_double         = Sensor_Ankle_L(:,end);
    time_axis_windows_double = time_axis_double(1:300:end);
    PacketCounter_windows = table(time_axis_windows_double(1:windows));
    PacketCounter_windows.Properties.VariableNames{1} = 'PacketCounter';
    file_name = ds.Files(measurement_indices(1,1));
    D0 = datetime(char(file_name{1}(end-22:end-15)),'InputFormat','yyyyMMdd',"Format","dd-MMM-yyyy HH:mm:ss.SSS");
    spf = @(x) sprintf('%010d',x);
    Table_windows_total.Datetime = timeofday(datetime(rowfun(spf,PacketCounter_windows(:,'PacketCounter'),"OutputFormat","cell"),'InputFormat',"HHmmssSSS"));
    Table_windows_total.Datetime = Table_windows_total.Datetime + D0;
    df = [0; diff(Table_windows_total.Datetime)<0];
    Table_windows_total.Datetime = Table_windows_total.Datetime + cumsum(days(df));
    TT{Q,1} = table2timetable(Table_windows_total,'RowTimes','Datetime');
    TT{Q,1} = rmmissing(TT{Q,1});
    end
    
    %%% Find startpoints videos and lengths videos
    %clear vid_Active vid_name_Active vid_start_Active_cell vid_Active_samples_xsens_cell vid_Inactive vid_name_Inactive vid_start_Inactive_cell vid_Inactive_samples_xsens_cell
    clear Sensor_Ankle_L Sensor_Ankle_R Sensor_Wrist_L Sensor_Wrist_R start_points_index end_points_index N idx_videos_found idx_ones X X2 X3 X4 X5 Matrices Matrices_videos 

    if Q==1
        for i = 1:vids_Active_per_map(Q)
            vid_Active{i} = VideoReader(char(ds_videos.Files(i)));                                             
            vid_name_Active{i} = vid_Active{1,i}.Name;
            vid_start_Active_cell{i} = str2num(cell2mat(extractBetween(vid_name_Active{i},"Active_","_20")));
            vid_Active_samples_xsens_cell{i} = vid_Active{1,i}.duration * fs_xsens;
        end
        for i = vids_Active_per_map(Q)+1:vids_Active_per_map(Q) + vids_Inactive_per_map(Q)
            vid_Inactive{i-vids_Active_per_map(Q)} = VideoReader(char(ds_videos.Files(i)));                                             
            vid_name_Inactive{i-vids_Active_per_map(Q)} = vid_Inactive{1,i-vids_Active_per_map(Q)}.Name;
            vid_start_Inactive_cell{i-vids_Active_per_map(Q)} = str2num(cell2mat(extractBetween(vid_name_Inactive{i-vids_Active_per_map(Q)},"Inactive_","_20")));
            vid_Inactive_samples_xsens_cell{i-vids_Active_per_map(Q)} = vid_Inactive{1,i-vids_Active_per_map(Q)}.duration * fs_xsens;
        end
    else 
        for i = 1+sum(vids2(:,1:Q-1),'all') : vids_Active_per_map(Q)+sum(vids2(:,1:Q-1),'all')
            vid_Active{i} = VideoReader(char(ds_videos.Files(i)));                                             
            vid_name_Active{i} = vid_Active{1,i}.Name;
            vid_start_Active_cell{i} = str2num(cell2mat(extractBetween(vid_name_Active{i},"Active_","_20")));
            vid_Active_samples_xsens_cell{i} = vid_Active{1,i}.duration * fs_xsens;
        end    
        for i = 1+sum(vids2(:,1:Q-1),'all')+vids_Active_per_map(Q) : vids_Inactive_per_map(Q)+sum(vids2(:,1:Q-1),'all')+vids_Active_per_map(Q)
            vid_Inactive{i-vids_Active_per_map(Q)} = VideoReader(char(ds_videos.Files(i)));                                             
            vid_name_Inactive{i-vids_Active_per_map(Q)} = vid_Inactive{1,i-vids_Active_per_map(Q)}.Name;
            vid_start_Inactive_cell{i-vids_Active_per_map(Q)} = str2num(cell2mat(extractBetween(vid_name_Inactive{i-vids_Active_per_map(Q)},"Inactive_","_20")));
            vid_Inactive_samples_xsens_cell{i-vids_Active_per_map(Q)} = vid_Inactive{1,i-vids_Active_per_map(Q)}.duration * fs_xsens;
        end
    end
    
    % Active. Clear empty values & cell to double
    if exist('vid_Active') == 1
        vid_Active                      = vid_Active(~cellfun('isempty',vid_Active));
        vid_name_Active                 = vid_name_Active(~cellfun('isempty',vid_name_Active));
        vid_start_Active_cell           = vid_start_Active_cell(~cellfun('isempty',vid_start_Active_cell));
        vid_Active_samples_xsens_cell   = vid_Active_samples_xsens_cell(~cellfun('isempty',vid_Active_samples_xsens_cell));
        vid_start_Active                = cell2mat(vid_start_Active_cell);           % start points (SampleTimeFine) of Active videos
        vid_Active_samples_xsens        = cell2mat(vid_Active_samples_xsens_cell);   % length of Active videos expressed in number of samples of the sensor data
        N_Active                        = floor(vid_Active_samples_xsens / window_length);     % number of 5s time windows per Active video
        idx_windows_Active              = find(N_Active>0);                                    % Index of Active videos that have at least 1 whole 5d time window

    end 
    
    % Inactive. Clear empty values & cell to double
    if exist('vid_Inactive') == 1
        vid_Inactive                    = vid_Inactive(~cellfun('isempty',vid_Inactive));
        vid_name_Inactive               = vid_name_Inactive(~cellfun('isempty',vid_name_Inactive));
        id_start_Inactive_cell          = vid_start_Inactive_cell(~cellfun('isempty',vid_start_Inactive_cell));
        vid_Inactive_samples_xsens_cell = vid_Inactive_samples_xsens_cell(~cellfun('isempty',vid_Inactive_samples_xsens_cell));
        vid_start_Inactive              = cell2mat(vid_start_Inactive_cell);         % start points (SampleTimeFine) of Inactive videos
        vid_Inactive_samples_xsens      = cell2mat(vid_Inactive_samples_xsens_cell); % length of Inactive videos expressed in number of samples of the sensor data
        N_Inactive                      = floor(vid_Inactive_samples_xsens / window_length);   % number of 5s time windows per Iactive video
        idx_windows_Inactive            = find(N_Inactive>0);                                  % Index of Inactive videos that have at least 1 whole 5d time window
    end
    
    if exist('vid_Active') == 1 && exist('vid_Inactive') == 1
        videostart      = [vid_start_Active vid_start_Inactive];
        videosamples    = [vid_Active_samples_xsens vid_Inactive_samples_xsens];
        N               = [N_Active N_Inactive];
    end
    if exist('vid_Active') == 1 && exist('vid_Inactive') == 0
        videostart      = [vid_start_Active];
        videosamples    = [vid_Active_samples_xsens];
        N               = [N_Active];
    end
    if exist('vid_Active') == 0 && exist('vid_Inactive') == 1
        videostart      = [vid_start_Inactive];
        videosamples    = [vid_Inactive_samples_xsens];
        N               = [N_Inactive];
    end
    
    % find start points and end points of videos in sensor data
    dt = 1 / fs_xsens;

        for i = 1 : length(videostart)
                start_points_index{i} = find(table2array(Table(:,1))==videostart(i));                
                end_points_index{i}   = start_points_index{i} + videosamples(i);
        end
    
                for i = 1:length(videostart)
                if start_points_index{1, i} > 0  
                    idx_ones(i,1) = 1;
                else idx_ones(i,1) = 0;
                end
        end
        idx_videos_not_found = find(idx_ones==0);
        [idx_videos_found,~] = find(idx_ones==1);
        lost_videos_amount{1,Q} = length(idx_videos_not_found);
        disp("Number of videos not found in measurement " + string(subFolders_names(Q)) + " is: " + string(lost_videos_amount{1,Q}))
        lost_videos_idx{1,Q} = idx_videos_not_found;
        
        for i = idx_videos_not_found
            start_points_index(idx_videos_not_found) = {-1};
            end_points_index(idx_videos_not_found)   = {-1};
        end
        
    start_points_index = cell2mat(start_points_index); 
    end_points_index = cell2mat(end_points_index);
    
    start_end_videos_index = [start_points_index ; end_points_index];
    
    % calculate number of 5s time windows per video
    N_videos = N;
    N = N(idx_videos_found);
    [~, idx_N] = find(N>0);
    N                    = N(N>0);                                              % number of 5s time windows per video 
    N_videos_total{Q,1} = N_videos;
    
        % Matrix with sensor data for each video > 5 seconds
    if exist('vid_Active') == 1
        %for i=idx_windows_Active 
         idx=idx_windows_Active ;
                for j = size(lost_videos_idx{1, Q}  ,1)
            if j>0
                for k = 1:j
                idx_del{k} = find(idx == lost_videos_idx{1, Q}(k));
                end
            idx_del2 = idx_del(~cellfun('isempty',idx_del));
            idx_del2 = cell2mat(idx_del2);
            idx(idx_del2) = [];
            end
        end
        for i=idx    
                my_field_Active = strcat('Matrice_Active',num2str(i));
                Matrices.(my_field_Active) = Table(start_points_index(i):end_points_index(i),:);
        end
    end
    if exist('vid_Active') == 1 && exist('vid_Inactive') == 1
        idx=idx_windows_Inactive+length(vid_name_Active);
                for j = size(lost_videos_idx{1, Q}  ,1)
            if j>0
                for k = 1:j
                idx_del{k} = find(idx == lost_videos_idx{1, Q}(k));
                end
            idx_del2 = idx_del(~cellfun('isempty',idx_del));
            idx_del2 = cell2mat(idx_del2);
            idx(idx_del2) = [];
            end
        end
        for i=idx 
                my_field_Inactive = strcat('Matrice_Inactive',num2str(i));
                Matrices.(my_field_Inactive) = Table(start_points_index(i):end_points_index(i),:);
        end
    end
    if exist('vid_Active') == 0 && exist('vid_Inactive') == 1
        %for i=idx_windows_Inactive; %height(ds_videos.Files);
        idx=idx_windows_Inactive;
        for j = size(lost_videos_idx{1, Q}  ,1)
            if j>0
                for k = 1:j
                idx_del{k} = find(idx == lost_videos_idx{1, Q}(k));
                end
            idx_del2 = idx_del(~cellfun('isempty',idx_del));
            idx_del2 = cell2mat(idx_del2);
            idx(idx_del2) = [];
            end
        end
        for i=idx         
                my_field_Inactive = strcat('Matrice_Inactive',num2str(i));
                Matrices.(my_field_Inactive) = Table(start_points_index(i):end_points_index(i),:);
        end
    end
    
    % Create one large table [windows, features] for machine learning 
    if isempty(idx) == 0;
    ii = sum(vids_total_per_map(:,1:Q-1))+1 :  sum(vids_total_per_map(:,1:Q-1))+vids_total_per_map(Q);
    Matrices_videos = struct2table(Matrices,'AsArray',true);
        for j = 1:44
            for i = 1:length(N)
                X = Matrices_videos(1,i);
                X2 = X{1,1};
                X3 = X2{1,1};
                X3(N(i)*window_length+1:end,:)=[];
                X4=table2array(X3(:,j+1));
                X5 = reshape(X4,[],N(i));
                X5 = X5';
                Table_windows{i,j} = table(X5);
                check_mp4_names = cell2mat(extractBetween(ds_videos.Files{ii(idx_N(i)), 1},[subFolders_names{Q,1} char('\')],'.mp4'));
                Table_windows{i,45}=table(repmat(string(check_mp4_names),N(i),1));
                Table_windows{i,46}=table([1:N(i)]');
            end
        end
     
    % create a new variable name for each column
        for j = 1:length(N); 
            for i = 1:44
                Table_windows{j, i}.Properties.VariableNames{1} = char("feature"+string(i));
            end
        end

    % Add tables vertically
        for i = 1:46
            my_field = strcat('F',num2str(i));
            Tables_vert.(my_field) = vertcat(Table_windows{:,i});      
        end
    
    
    % Add tables horizontally
    TABLE_ML_per_measurement{Q,1} = struct2table(Tables_vert);

    % Add label 'Active' or 'Inactive'
    ZEROS = zeros(height(TABLE_ML_per_measurement{Q,1}),1);
    if exist('vid_Active') == 1
        ZEROS(sum(N_Active)+1:end)=1;
    end
    if exist('vid_Active') == 0
        ZEROS(1:end)=1;
    end 
    Classes = categorical(ZEROS,[0 1],{'Active' 'Inactive'});
    TABLE_ML_per_measurement{Q,1}.Class = Classes;  
    
    % Clinical scores
    for p = 1:size(scorers,1)
       if isempty(files_data_scores) == 0
           % ii = sum(scored_videos_per_folder(:,1:Q-1))+1 :  sum(scored_videos_per_folder(:,1:Q-1))+scored_videos_per_folder(Q);
            ii = sum(vids_total_per_map(:,1:Q-1))+1 :  sum(vids_total_per_map(:,1:Q-1))+vids_total_per_map(Q);
            for video = 1:scored_videos_per_folder(Q,p)                     %height(files_data_scores)
                %clinical_scores = readtable(ds_scores.Files{ii(video), 1});
                %clinical_scores_windows{video,1} = clinical_scores(1:N_videos(video),7:19);
                clear clinical_scores
                %clinical_scores = read_score(ds_scores.Files{ii(video), 1});
                clinical_scores = read_score(string(ds_scores_scorers{1, p}(ii(video))));
                if size(clinical_scores,1) == N_videos(video)
                    check_length(video) = 1; 
                else check_length(video) = 0;
                end 
                N_CS(video) = size(clinical_scores,1);
                %clinical_scores_windows{video,1} = clinical_scores(1:N_videos(video),:);
                clinical_scores_windows{video,1} = clinical_scores(:,:);
                %check_txt_names = cell2mat(extractBetween(ds_scores.Files{ii(video), 1},[subFolders_names{Q,1} char('\')],'.txt'));
                check_txt_names = cell2mat(extractBetween(string(ds_scores_scorers{1, p}(ii(video))),[subFolders_names{Q,1} char('\')],'.txt'));
                clinical_scores_windows{video,1}.file_name_txt = repmat(string(check_txt_names),N_videos(video),1);
                clinical_scores_windows{video,1}.window_number_score = [1:N_videos(video)]';
            end
            check_length_total{Q,1} = check_length;
            N_CS_total{Q,1} = N_CS;

           %clinical_scores_windows = clinical_scores_windows(idx_N);
           clinical_scores_windows = clinical_scores_windows(idx_videos_found);

           %Add score tables vertically
           clinical_scores_windows_vert{Q,p} = vertcat(clinical_scores_windows{:});
       end
    end
    
    else
        disp('Empty (video not found)')
        TABLE_ML_per_measurement{Q,1} = [];
        for p = 1:size(scorers,1)
         clinical_scores_windows_vert{Q,p} = [];
        end
    end
    
    % if one the length of one measurement is greater than 1.2 times
    % another mearurement, it is likely that there was a synchronization
    % error 
    if length(S_Time)/length(S1t) > 1.2 || length(S_Time)/length(S2t) > 1.2 || length(S_Time)/length(S3t) > 1.2 || length(S_Time)/length(S4t) > 1.2
        ERROR{Q,1} = 1;
        disp('!! Error: synchronizing SampleTimeFine has likely failed !!')
    else ERROR{Q,1} = [];
    end  
    
end


% Table with the sensordata per signal
TABLE_ML_TOTAL = vertcat(TABLE_ML_per_measurement{:,1}); 
TABLE_ML_TOTAL = movevars(TABLE_ML_TOTAL, 'Class', 'Before', 'F1');
TABLE_ML_TOTAL.Properties.VariableNames = {'Class','AL_Acc_X','AL_Acc_Y','AL_Acc_Z','AL_Acc_T','AL_Gyr_X','AL_Gyr_Y','AL_Gyr_Z','AL_Gyr_T','AL_Euler_X','AL_Euler_Y','AL_Euler_Z','AR_Acc_X','AR_Acc_Y','AR_Acc_Z','AR_Acc_T','AR_Gyr_X','AR_Gyr_Y','AR_Gyr_Z','AR_Gyr_T','AR_Euler_X','AR_Euler_Y','AR_Euler_Z','WL_Acc_X','WL_Acc_Y','WL_Acc_Z','WL_Acc_T','WL_Gyr_X','WL_Gyr_Y','WL_Gyr_Z','WL_Gyr_T','WL_Euler_X','WL_Euler_Y','WL_Euler_Z','WR_Acc_X','WR_Acc_Y','WR_Acc_Z','WR_Acc_T','WR_Gyr_X','WR_Gyr_Y','WR_Gyr_Z','WR_Gyr_T','WR_Euler_X','WR_Euler_Y','WR_Euler_Z','Video','Window'};
Class    = TABLE_ML_TOTAL.Class;


% Combine left and right 
% Upper
TABLE_ML_TOTAL_upper_L = TABLE_ML_TOTAL(:,[1:12 46 47]);
TABLE_ML_TOTAL_upper_R = TABLE_ML_TOTAL(:,[1 13:23 46 47]);
var_names = {'Class','Acc_X','Acc_Y','Acc_Z','Acc_T','Gyr_X','Gyr_Y','Gyr_Z','Gyr_T','Euler_X','Euler_Y','Euler_Z','Video','Window'};
TABLE_ML_TOTAL_upper_L.Properties.VariableNames = var_names;
TABLE_ML_TOTAL_upper_R.Properties.VariableNames = var_names;
TABLE_ML_TOTAL_upper_R.Acc_X.Properties.VariableNames = {'feature1'};
TABLE_ML_TOTAL_upper_R.Acc_Y.Properties.VariableNames = {'feature2'};
TABLE_ML_TOTAL_upper_R.Acc_Z.Properties.VariableNames = {'feature3'};
TABLE_ML_TOTAL_upper_R.Acc_T.Properties.VariableNames = {'feature4'};
TABLE_ML_TOTAL_upper_R.Gyr_X.Properties.VariableNames = {'feature5'};
TABLE_ML_TOTAL_upper_R.Gyr_Y.Properties.VariableNames = {'feature6'};
TABLE_ML_TOTAL_upper_R.Gyr_Z.Properties.VariableNames = {'feature7'};
TABLE_ML_TOTAL_upper_R.Gyr_T.Properties.VariableNames = {'feature8'};
TABLE_ML_TOTAL_upper_R.Euler_X.Properties.VariableNames = {'feature9'};
TABLE_ML_TOTAL_upper_R.Euler_Y.Properties.VariableNames = {'feature10'};
TABLE_ML_TOTAL_upper_R.Euler_Z.Properties.VariableNames = {'feature11'};
TABLE_ML_TOTAL_upper_R.Acc_Y.feature2 = -TABLE_ML_TOTAL_upper_R.Acc_Y.feature2;
TABLE_ML_TOTAL_upper_R.Gyr_Y.feature6 = -TABLE_ML_TOTAL_upper_R.Gyr_Y.feature6;
TABLE_ML_TOTAL_upper_R.Euler_Y.feature10 = -TABLE_ML_TOTAL_upper_R.Euler_Y.feature10;
TABLE_ML_TOTAL_upper = [TABLE_ML_TOTAL_upper_L; TABLE_ML_TOTAL_upper_R];

% Lower
TABLE_ML_TOTAL_lower_L = TABLE_ML_TOTAL(:,[1 24:34 46 47]);
TABLE_ML_TOTAL_lower_R = TABLE_ML_TOTAL(:,[1 35:47]);
var_names = {'Class','Acc_X','Acc_Y','Acc_Z','Acc_T','Gyr_X','Gyr_Y','Gyr_Z','Gyr_T','Euler_X','Euler_Y','Euler_Z','Video','Window'};
TABLE_ML_TOTAL_lower_L.Properties.VariableNames = var_names;
TABLE_ML_TOTAL_lower_R.Properties.VariableNames = var_names;
TABLE_ML_TOTAL_lower_R.Acc_X.Properties.VariableNames = {'feature23'};
TABLE_ML_TOTAL_lower_R.Acc_Y.Properties.VariableNames = {'feature24'};
TABLE_ML_TOTAL_lower_R.Acc_Z.Properties.VariableNames = {'feature25'};
TABLE_ML_TOTAL_lower_R.Acc_T.Properties.VariableNames = {'feature26'};
TABLE_ML_TOTAL_lower_R.Gyr_X.Properties.VariableNames = {'feature27'};
TABLE_ML_TOTAL_lower_R.Gyr_Y.Properties.VariableNames = {'feature28'};
TABLE_ML_TOTAL_lower_R.Gyr_Z.Properties.VariableNames = {'feature29'};
TABLE_ML_TOTAL_lower_R.Gyr_T.Properties.VariableNames = {'feature30'};
TABLE_ML_TOTAL_lower_R.Euler_X.Properties.VariableNames = {'feature31'};
TABLE_ML_TOTAL_lower_R.Euler_Y.Properties.VariableNames = {'feature32'};
TABLE_ML_TOTAL_lower_R.Euler_Z.Properties.VariableNames = {'feature33'};
TABLE_ML_TOTAL_lower_R.Acc_Y.feature24 = -TABLE_ML_TOTAL_lower_R.Acc_Y.feature24;
TABLE_ML_TOTAL_lower_R.Gyr_Y.feature28 = -TABLE_ML_TOTAL_lower_R.Gyr_Y.feature28;
TABLE_ML_TOTAL_lower_R.Euler_Y.feature32 = -TABLE_ML_TOTAL_lower_R.Euler_Y.feature32;
TABLE_ML_TOTAL_lower = [TABLE_ML_TOTAL_lower_L; TABLE_ML_TOTAL_lower_R];

load_TABLE_ML_TOTAL         = "load_TABLE_ML_TOTAL_"         + string(DIR(end-9:end)) + ".mat";
save(load_TABLE_ML_TOTAL, 'TABLE_ML_TOTAL','TABLE_ML_TOTAL_lower','TABLE_ML_TOTAL_upper');


%%% 
lost_videos_amount

if isempty(files_data_scores) == 0
    for p = 1:size(scorers,1)
        Clinical_Scores_TOTAL{1,p} = vertcat(clinical_scores_windows_vert{:,p});
    
        % Final check if videos match clinical scores
        for i=1:size(Clinical_Scores_TOTAL{1,p},1)
            CS_file_name_txt = char(Clinical_Scores_TOTAL{1,p}.file_name_txt(i));
            CS_file_name_txt = CS_file_name_txt(1:end-4);
            CS_file_name_txt = string(CS_file_name_txt);
            if CS_file_name_txt == TABLE_ML_TOTAL.Video(i,:).Var1(1) || Clinical_Scores_TOTAL{1,p}.window_number_score(i) == TABLE_ML_TOTAL.Window(i,:).Var1(1)
            check_videos_scores(i) = 1;
            else
            check_videos_scores(i) = 0;
            end
        end
    end
    final_check = find(check_videos_scores==0);
    if isempty(final_check) == 1
        disp('Videos are correctly linked to clinical scores')
    else disp('!! ERROR: videos are incorrectly linked to clinical scores !!')
    end
end

% Average clinical score
Clinical_Scores_TOTAL_median = Clinical_Scores_TOTAL{1,1};
for i = 1:13
    clear idx_del
    Clinical_Scores_TOTAL_median{:,i} = median([table2array(Clinical_Scores_TOTAL{1,1}(:,i)) table2array(Clinical_Scores_TOTAL{1,2}(:,i)) table2array(Clinical_Scores_TOTAL{1,3}(:,i)) ],2,'omitnan');
    idx_del = find(Clinical_Scores_TOTAL_median{:,i} == 0.5 | Clinical_Scores_TOTAL_median{:,i} == 1.5 | Clinical_Scores_TOTAL_median{:,i} == 2.5 | Clinical_Scores_TOTAL_median{:,i} == 3.5);
    Clinical_Scores_TOTAL_median{:,i}(idx_del) = nan;
end

      
        
load_Clinical_Scores_TOTAL = "load_Clinical_Scores_TOTAL_"  + string(DIR(end-9:end)) + ".mat";
save(load_Clinical_Scores_TOTAL, 'Clinical_Scores_TOTAL','Clinical_Scores_TOTAL_median');


% save this part of the code so that is can be loaded when running this
% code again
DIR = pwd;
Patient = DIR(end-9:end); 
load_preprocessed_data = "load_preprocessed_data_" + string(DIR(end-9:end)) + ".mat";
save(load_preprocessed_data, 'TABLE_ML_TOTAL','TABLE_ML_TOTAL_lower','TABLE_ML_TOTAL_upper', 'Class', 'Clinical_Scores_TOTAL','Clinical_Scores_TOTAL_median','ds','file_indices','window_length')
    if exist('TT') == 1
        load_Timetables_all_day = "load_Timetables_all_day_" + string(DIR(end-9:end)) + ".mat";
        save(load_Timetables_all_day, 'TT')
    end
%end



clear all
clc

% Choose for which extremities a ML model should be trained
dystonia_lower          =   "yes";
dystonia_upper          =   "yes";
choreoathetosis_lower   =   "yes";
choreoathetosis_upper   =   "yes";
dystonia_total          =   "no";
choreoathetosis_total   =   "no";

% Choose which type of model to train
machine_learning        =   "yes";
deep_learning           =   "yes";

% Oversampling
oversampling            =   "yes";

% Load the preprocessed data
disp('Loading data...')
DIR = pwd;
Patient = char(DIR(end-9:end));                            
load_name = "load_preprocessed_data_" + string(Patient) + ".mat";
load(load_name)
disp('Complete') ; disp(' ')

   
% Create dataframes for machine learning & deep learning. (Funtion 2)
disp('Creating dataframes for machine learning...')
[dataframes, dataframeTrain_dystonia_upper , dataframeTrain_dystonia_lower , dataframeTrain_choreoathetosis_upper , dataframeTrain_choreoathetosis_lower , dataframeTrain_dystonia_total , dataframeTrain_choreoathetosis_total] = function_create_dataframes(TABLE_ML_TOTAL, TABLE_ML_TOTAL_upper, TABLE_ML_TOTAL_lower, Class, Clinical_Scores_TOTAL_median);
disp('Complete') ; disp(' ')

% Determine which extremities to model. (Function 1)
disp('Determining which extremities are being modelled...')
extremity_idx = function_index_extremities(dystonia_lower, dystonia_upper, choreoathetosis_lower, choreoathetosis_upper, dystonia_total, choreoathetosis_total, dataframes);
disp('Complete') ; disp(' ')

% Partitioning data in training and testing data. (Function 3)
disp('Partitioning the data in training and testing data...')
[trainInd, testInd, trainInd_DL, testInd_DL, valInd_DL, size_y_test_DL, size_y_val_DL] = function_partition_data(dataframes);
disp('Complete') ; disp(' ')


%save(load_name, 'Class','Clinical_Scores_TOTAL','Clinical_Scores_TOTAL_median','TABLE_ML_TOTAL','TABLE_ML_TOTAL_lower','TABLE_ML_TOTAL_upper','trainInd', 'testInd', 'trainInd_DL', 'testInd_DL', 'valInd_DL', 'size_y_test_DL', 'size_y_val_DL')





%%
%%% fuction myread 
function v = myread(file)
   v=VideoReader(file);
end



%%% function read_scores
function clinical_scores = read_score(dir_score)

%Table_scores = readtable('Active_2044258322_2021-09-29T143555.717_video_HHA.txt');
Table_scores = readtable(dir_score);

if string(class(Table_scores.Dystonia_lower_extremity_right(1))) == string('cell')
score1 = str2double(Table_scores.Dystonia_lower_extremity_right);
else score1 = Table_scores.Dystonia_lower_extremity_right;
end
[idx_score1,~] = find(~isnan(score1)==1);
score1_values=(score1(~isnan(score1)));
if size(idx_score1,1) > 1
for i = 1:length(score1_values)-1
score1_rep{i,1} = repmat(score1_values(i),idx_score1(i+1)-idx_score1(i),1);
end
score1_rep{i+1,1} = score1_values(end);
score1 = vertcat(cell2mat(score1_rep));
else score1 = score1_values;
end
score1(score1 == 999) = NaN;

if string(class(Table_scores.Dystonia_lower_extremity_left(1))) == string('cell')
score2 = str2double(Table_scores.Dystonia_lower_extremity_left);
else score2 = Table_scores.Dystonia_lower_extremity_left;
end
[idx_score2,~] = find(~isnan(score2)==1);
score2_values=(score2(~isnan(score2)));
if size(idx_score2,1) > 1
for i = 1:length(score2_values)-1
score2_rep{i,1} = repmat(score2_values(i),idx_score2(i+1)-idx_score2(i),1);
end
score2_rep{i+1,1} = score2_values(end);
score2 = vertcat(cell2mat(score2_rep));
else score2 = score2_values;
end
score2(score2 == 999) = NaN;

if string(class(Table_scores.Dystonia_upper_extremity_right(1))) == string('cell')
score3 = str2double(Table_scores.Dystonia_upper_extremity_right);
else score3 = Table_scores.Dystonia_upper_extremity_right;
end
[idx_score3,~] = find(~isnan(score3)==1);
score3_values=(score3(~isnan(score3)));
if size(idx_score3,1) > 1
for i = 1:length(score3_values)-1
score3_rep{i,1} = repmat(score3_values(i),idx_score3(i+1)-idx_score3(i),1);
end
score3_rep{i+1,1} = score3_values(end);
score3 = vertcat(cell2mat(score3_rep));
else score3 = score3_values;
end
score3(score3 == 999) = NaN;

if string(class(Table_scores.Dystonia_upper_extemity_left(1))) == string('cell')
score4 = str2double(Table_scores.Dystonia_upper_extemity_left);
else score4 = Table_scores.Dystonia_upper_extemity_left;
end
[idx_score4,~] = find(~isnan(score4)==1);
score4_values=(score4(~isnan(score4)));
if size(idx_score4,1) > 1
for i = 1:length(score4_values)-1
score4_rep{i,1} = repmat(score4_values(i),idx_score4(i+1)-idx_score4(i),1);
end
score4_rep{i+1,1} = score4_values(end);
score4 = vertcat(cell2mat(score4_rep));
else score4 = score4_values;
end
score4(score4 == 999) = NaN;

if string(class(Table_scores.Dystonia_neck(1))) == string('cell')
score5 = str2double(Table_scores.Dystonia_neck);
else score5 = Table_scores.Dystonia_neck;
end
[idx_score5,~] = find(~isnan(score5)==1);
score5_values=(score5(~isnan(score5)));
if size(idx_score5,1) > 1
for i = 1:length(score5_values)-1
score5_rep{i,1} = repmat(score5_values(i),idx_score5(i+1)-idx_score5(i),1);
end
score5_rep{i+1,1} = score5_values(end);
score5 = vertcat(cell2mat(score5_rep));
else score5 = score5_values;
end
score5(score5 == 999) = NaN;

if string(class(Table_scores.Dystonia_trunk(1))) == string('cell')
score6 = str2double(Table_scores.Dystonia_trunk);
else score6 = Table_scores.Dystonia_trunk;
end
[idx_score6,~] = find(~isnan(score6)==1);
score6_values=(score6(~isnan(score6)));
if size(idx_score6,1) > 1
for i = 1:length(score6_values)-1
score6_rep{i,1} = repmat(score6_values(i),idx_score6(i+1)-idx_score6(i),1);
end
score6_rep{i+1,1} = score6_values(end);
score6 = vertcat(cell2mat(score6_rep));
else score6 = score6_values;
end
score6(score6 == 999) = NaN;

if string(class(Table_scores.Choreoathetose_lower_extremity_right(1))) == string('cell')
score7 = str2double(Table_scores.Choreoathetose_lower_extremity_right);
else score7 = Table_scores.Choreoathetose_lower_extremity_right;
end
[idx_score7,~] = find(~isnan(score7)==1);
score7_values=(score7(~isnan(score7)));
if size(idx_score7,1) > 1
for i = 1:length(score7_values)-1
score7_rep{i,1} = repmat(score7_values(i),idx_score7(i+1)-idx_score7(i),1);
end
score7_rep{i+1,1} = score7_values(end);
score7 = vertcat(cell2mat(score7_rep));
else score7 = score7_values;
end
score7(score7 == 999) = NaN;

if string(class(Table_scores.Choreoathetosis_lower_extremity_left(1))) == string('cell')
score8 = str2double(Table_scores.Choreoathetosis_lower_extremity_left);
else score8 = Table_scores.Choreoathetosis_lower_extremity_left;
end
[idx_score8,~] = find(~isnan(score8)==1);
score8_values=(score8(~isnan(score8)));
if size(idx_score8,1) > 1
for i = 1:length(score8_values)-1
score8_rep{i,1} = repmat(score8_values(i),idx_score8(i+1)-idx_score8(i),1);
end
score8_rep{i+1,1} = score8_values(end);
score8 = vertcat(cell2mat(score8_rep));
else score8 = score8_values;
end
score8(score8 == 999) = NaN;

if string(class(Table_scores.Choreoathetosis_upper_extremity_right(1))) == string('cell')
score9 = str2double(Table_scores.Choreoathetosis_upper_extremity_right);
else score9 = Table_scores.Choreoathetosis_upper_extremity_right;
end
[idx_score9,~] = find(~isnan(score9)==1);
score9_values=(score9(~isnan(score9)));
if size(idx_score9,1) > 1
for i = 1:length(score9_values)-1
score9_rep{i,1} = repmat(score9_values(i),idx_score9(i+1)-idx_score9(i),1);
end
score9_rep{i+1,1} = score9_values(end);
score9 = vertcat(cell2mat(score9_rep));
else score9 = score9_values;
end
score9(score9 == 999) = NaN;

if string(class(Table_scores.Choreoathetosis_upper_extremity_left(1))) == string('cell')
score10 = str2double(Table_scores.Choreoathetosis_upper_extremity_left);
else score10 = Table_scores.Choreoathetosis_upper_extremity_left;
end
[idx_score10,~] = find(~isnan(score10)==1);
score10_values=(score10(~isnan(score10)));
if size(idx_score10,1) > 1
for i = 1:length(score10_values)-1
score10_rep{i,1} = repmat(score10_values(i),idx_score10(i+1)-idx_score10(i),1);
end
score10_rep{i+1,1} = score10_values(end);
score10 = vertcat(cell2mat(score10_rep));
else score10 = score10_values;
end
score10(score10 == 999) = NaN;

if string(class(Table_scores.Choreoathetosis_neck(1))) == string('cell')
score11 = str2double(Table_scores.Choreoathetosis_neck);
else score11 = Table_scores.Choreoathetosis_neck;
end
[idx_score11,~] = find(~isnan(score11)==1);
score11_values=(score11(~isnan(score11)));
if size(idx_score11,1) > 1
for i = 1:length(score11_values)-1
score11_rep{i,1} = repmat(score11_values(i),idx_score11(i+1)-idx_score11(i),1);
end
score11_rep{i+1,1} = score11_values(end);
score11 = vertcat(cell2mat(score11_rep));
else score11 = score11_values;
end
score11(score11 == 999) = NaN;

if string(class(Table_scores.Choreoathetosis_trunk(1))) == string('cell')
score12 = str2double(Table_scores.Choreoathetosis_trunk);
else score12 = Table_scores.Choreoathetosis_trunk;
end
[idx_score12,~] = find(~isnan(score12)==1);
score12_values=(score12(~isnan(score12)));
if size(idx_score12,1) > 1
for i = 1:length(score12_values)-1
score12_rep{i,1} = repmat(score12_values(i),idx_score12(i+1)-idx_score12(i),1);
end
score12_rep{i+1,1} = score12_values(end);
score12 = vertcat(cell2mat(score12_rep));
else score12 = score12_values;
end
score12(score12 == 999) = NaN;

if string(class(Table_scores.Position(1))) == string('cell')
score13 = str2double(Table_scores.Position);
else score13 = Table_scores.Position;
end
score13(score13 == 999) = NaN;
[idx_score13,~] = find(~isnan(score13)==1);
if length(idx_score13)>1
    score13_values=(score13(~isnan(score13)));
    for i = 1:length(score13_values)-1
    score13_rep{i,1} = repmat(score13_values(i),idx_score13(i+1)-idx_score13(i),1);
    end
    score13_rep{i+1,1} = score13_values(end);
    score13 = vertcat(cell2mat(score13_rep));
else score13 = repmat(score13(1),length(score1),1);
end

score14 = repmat(string(Table_scores.Activity(1)),length(score1),1);

% if string(class(Table_scores.Moved_passively(1))) == string('cell')
% score15 = str2double(Table_scores.Position);
% else score15 = Table_scores.Position;
% end
% score15(score15 == 999) = NaN;
% [idx_score15,~] = find(~isnan(score15)==1);
% if length(idx_score15)>1
%     score15_values=(score15(~isnan(score15)));
%     for i = 1:length(score15_values)-1
%     score15_rep{i,1} = repmat(score15_values(i),idx_score15(i+1)-idx_score15(i),1);
%     end
%     score15_rep{i+1,1} = score15_values(end);
%     score15 = vertcat(cell2mat(score15_rep));
% else score15 = repmat(score15(1),length(score1),1);
% end

%clinical_scores  = [table(score1) table(score2) table(score3) table(score4) table(score5) table(score6) table(score7) table(score8) table(score9) table(score10) table(score11) table(score12) table(score13) table(score14) table(score15)];
clinical_scores  = [table(score1) table(score2) table(score3) table(score4) table(score5) table(score6) table(score7) table(score8) table(score9) table(score10) table(score11) table(score12) table(score13) table(score14)];

column_names = {'Dystonia_lower_extremity_right' 'Dystonia_lower_extremity_left' 'Dystonia_upper_extremity_right' 'Dystonia_upper_extemity_left' 'Dystonia_neck' 'Dystonia_trunk' 'Choreoathetose_lower_extremity_right' 'Choreoathetosis_lower_extremity_left' 'Choreoathetosis_upper_extremity_right' 'Choreoathetosis_upper_extremity_left' 'Choreoathetosis_neck' 'Choreoathetosis_trunk' 'Position' 'Activity'};
clinical_scores  = [table(score1) table(score2) table(score3) table(score4) table(score5) table(score6) table(score7) table(score8) table(score9) table(score10) table(score11) table(score12) table(score13) table(score14)];
for i = 1:size(clinical_scores,2)
clinical_scores.Properties.VariableNames{i} = column_names{1,i};
end

end




%%% function sync_SampleTimeFine
function [S_Time, Error_SampleTimeFine, cut_off] = sync_SampleTimeFine(S1t, S2t, S3t, S4t, Sc, Q)

marge_start = 1000;

S1_start = S1t(1:marge_start);
S2_start = S2t(1:marge_start);
S3_start = S3t(1:marge_start);
S4_start = S4t(1:marge_start);

inter = intersect(intersect(intersect(S1_start,S2_start),S3_start),S4_start);
inter = inter(1);

idx_S1_start  = find(S1t==inter);
idx_S2_start  = find(S2t==inter);
idx_S3_start  = find(S3t==inter);
idx_S4_start  = find(S4t==inter);

S1t = S1t(idx_S1_start:end);    
S2t = S2t(idx_S2_start:end); 
S3t = S3t(idx_S3_start:end); 
S4t = S4t(idx_S4_start:end); 

S1_end  = S1t(end);
S2_end  = S2t(end);
S3_end  = S3t(end);
S4_end  = S4t(end);
    
S = {S1t;S2t;S3t;S4t};

marge_end = 1000;

S_length = [length(S1t) length(S2t) length(S3t) length(S4t)];    

[~, S_idx_min_length] = min(S_length);
S_end_value = S{S_idx_min_length,1}(end-marge_end:end);
    
i_temp = [1:4];
i_temp(S_idx_min_length) = [];

for j= 1:marge_end+1
    for i = 1:4 
        S_idx_end2{i,j} = find(S{i,1} == S_end_value(j));
    end
end

S_idx_end = S_idx_end2;
S_idx_end2(S_idx_min_length,:) = [];

for i = [marge_end+1:-1:1]
        if S_idx_end2{1, i} > 0  &  S_idx_end2{2, i} > 0  &  S_idx_end2{3, i} > 0  
            idx_stop_ones(i,1) = 1;
        else idx_stop_ones(i,1) = 0;
        end
end

idx_stop = max(find(idx_stop_ones==1));

if isempty(idx_stop) == 1
    Error_SampleTimeFine = 1; 
    display('!! Sensor data shortened due to synchronization error !!')
    DIF = [0; diff(S1t)<0];
    jump = find(DIF==1);
   
    for i = 1:length(jump)
        S_value = S1t(jump(i)-300);
        S_idx_end_short2{i,1} = find(S2t == S_value);
        S_idx_end_short3{i,1} = find(S3t == S_value);
        S_idx_end_short4{i,1} = find(S4t == S_value);
    end

    S_idx_end_short2 = S_idx_end_short2(~cellfun('isempty',S_idx_end_short2));
    S_idx_end_short3 = S_idx_end_short3(~cellfun('isempty',S_idx_end_short3));
    S_idx_end_short4 = S_idx_end_short4(~cellfun('isempty',S_idx_end_short4));
    
    size_S_idx_end2 = length(S_idx_end_short2);
    size_S_idx_end3 = length(S_idx_end_short3);
    size_S_idx_end4 = length(S_idx_end_short4);
    
    if size_S_idx_end2 == size_S_idx_end3 || size_S_idx_end2 == size_S_idx_end4
        size_S_idx_end = size_S_idx_end2;
    else size_S_idx_end = [];
    end
    
    cut_off{Q,1} = jump(size_S_idx_end)-300;
    
    for i = 1:4
    S{i,1}(cut_off{Q,1}:end) = [];
    end
end

if isempty(idx_stop) == 0
    cut_off{Q,1} = [];
    Error_SampleTimeFine = [];  
    S{S_idx_min_length,1}(end-(marge_end-idx_stop):end) = [];

    if S_idx_end{1,idx_stop} > 0
        S{1,1}(S_idx_end{1,idx_stop}+1:end)=[];
    end
    if S_idx_end{2,idx_stop} > 0
        S{2,1}(S_idx_end{2,idx_stop}+1:end)=[];
    end
    if S_idx_end{3,idx_stop} > 0
        S{3,1}(S_idx_end{3,idx_stop}+1:end)=[];
    end
    if S_idx_end{4,idx_stop} > 0
       S{4,1}(S_idx_end{4,idx_stop}+1:end)=[];
    end
end

peaks1 = find(diff(S{1,1})<0==1);
peaks2 = find(diff(S{2,1})<0==1);
peaks3 = find(diff(S{3,1})<0==1);
peaks4 = find(diff(S{4,1})<0==1);
peaks      = [length(peaks1) length(peaks2) length(peaks3) length(peaks4)];

 if length(peaks1) > 0 & length(peaks2) > 0 & length(peaks3) > 0 & length(peaks4) > 0
        
        for i = 1
            S_u{i,1} = unique([S{1,1}(1:peaks1(i)); S{2,1}(1:peaks2(i)); S{3,1}(1:peaks3(i)); S{4,1}(1:peaks4(i))]);
        end
        for i = 2:min(peaks)
            S_u{i,1} = unique([S{1,1}(peaks1(i-1)+1:peaks1(i)); S{2,1}(peaks2(i-1)+1:peaks2(i)); S{3,1}(peaks3(i-1)+1:peaks3(i)); S{4,1}(peaks4(i-1)+1:peaks4(i))]);
        end
        for i = min(peaks)+1
            S_u{i,1} = unique([S{1,1}(peaks1(i-1)+1:end); S{2,1}(peaks2(i-1)+1:end); S{3,1}(peaks3(i-1)+1:end); S{4,1}(peaks4(i-1)+1:end)]);
        end
        
                S_Time = vertcat(S_u{:});
    
 else 
        Scm = cell2mat(S);                     % Convert To Matrix To Get Unique Times
        S_Time = unique(Scm(:,1),'stable');     % Unique SampleTimeFine's
 end
 
end
